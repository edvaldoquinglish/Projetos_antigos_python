# home.py
import flet as ft
from pages.results import ResultsPage
from backend.preprocessing import preprocess_image
from backend.model import predict_stone
from backend.utils import load_history, save_history
import os

class HomePage:
    def __init__(self, page):
        self.page = page
        self.history = load_history()

        # FilePicker
        self.file_picker = ft.FilePicker(on_result=self.file_picked)
        page.overlay.append(self.file_picker)

        # Preview da imagem
        self.img_preview = ft.Image(width=300, height=300)

        # Histórico UI
        self.history_list = ft.Column()
        self.update_history_ui()

        # Layout principal
        self.container = ft.Column([
            ft.Text("Rock Analyzer Avançado", size=30),
            ft.Row([
                ft.ElevatedButton("Selecionar Imagem", on_click=self.pick_file),
                ft.ElevatedButton("Limpar Histórico", on_click=self.clear_history)
            ]),
            self.img_preview,
            ft.Text("Histórico de análises:"),
            self.history_list
        ], alignment=ft.MainAxisAlignment.CENTER)

    def pick_file(self, e):
        self.file_picker.pick_files(allow_multiple=False)

    def file_picked(self, e: ft.FilePickerResultEvent):
        if e.files:
            file_path = e.files[0].path
            self.img_preview.src = file_path
            # Pré-processamento e predição
            img_array = preprocess_image(file_path)
            result = predict_stone(img_array)

            # Atualiza histórico
            self.history.append(result)
            save_history(self.history)
            self.update_history_ui()

            # Vai para tela de resultado
            self.page.controls.clear()
            self.page.add(ResultsPage(self.page, result, self.history).container)

    def clear_history(self, e):
        self.history = []
        save_history(self.history)
        self.update_history_ui()

    def update_history_ui(self):
        self.history_list.controls.clear()
        for item in reversed(self.history[-5:]):  # últimos 5
            color = "green" if item["confidence"] > 0.8 else "orange" if item["confidence"] > 0.5 else "red"
            self.history_list.controls.append(
                ft.Text(f"{item['stone']} ({item['confidence']*100:.1f}%)", color=color)
            )
            