# results.py
import flet as ft

class ResultsPage:
    def __init__(self, page, result, history):
        self.page = page
        self.result = result
        self.history = history

        color = "green" if result["confidence"] > 0.8 else "orange" if result["confidence"] > 0.5 else "red"

        self.container = ft.Column([
            ft.Text(f"Pedra detectada: {result['stone']}", size=28),
            ft.ProgressBar(width=300, value=result["confidence"], color=color),
            ft.Text(f"Confiança: {result['confidence']*100:.2f}%", color=color),
            ft.ElevatedButton("Voltar", on_click=self.go_back),
            ft.ElevatedButton("Gerar Relatório HTML", on_click=self.generate_report)
        ], alignment=ft.MainAxisAlignment.CENTER)

    def go_back(self, e):
        from pages.home import HomePage
        self.page.controls.clear()
        self.page.add(HomePage(self.page).container)

    def generate_report(self, e):
        from jinja2 import Environment, FileSystemLoader
        env = Environment(loader=FileSystemLoader("templates"))
        template = env.get_template("report_template.html")
        html_content = template.render(history=self.history)
        with open("data/report.html", "w") as f:
            f.write(html_content)
        ft.AlertDialog(title=ft.Text("Relatório Gerado!"), content=ft.Text("Arquivo salvo em data/report.html")).open(self.page)
        