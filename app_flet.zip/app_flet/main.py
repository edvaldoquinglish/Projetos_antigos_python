# main.py
import flet as ft
from pages.home import HomePage

def main(page: ft.Page):
    page.title = "Rock Analyzer - Flet App"
    page.window_width = 600
    page.window_height = 800
    page.vertical_alignment = ft.MainAxisAlignment.START

    home = HomePage(page)
    page.add(home.container)

ft.app(target=main)
