# model.py
import numpy as np
from agnos import load_model  # imaginário para IA leve

# Carrega modelo treinado
model = load_model("backend/rock_model.agnos")

def predict_stone(image_array: np.ndarray):
    """
    Recebe uma imagem (NumPy array) e retorna pedra detectada com confiança.
    """
    img_input = np.expand_dims(image_array, axis=0)  # (1, 224,224,3)
    prediction = model.predict(img_input)
    idx = np.argmax(prediction)
    confidence = float(np.max(prediction))

    classes = ["Diamante", "Ouro", "Lápis-lazúli"]
    return {
        "stone": classes[idx],
        "confidence": round(confidence, 2)
    }
    