# preprocessing.py
from PIL import Image
import numpy as np

def preprocess_image(file_path: str):
    """
    Abre a imagem, redimensiona para 224x224 e normaliza.
    """
    img = Image.open(file_path).convert("RGB")
    img = img.resize((224, 224))
    arr = np.array(img).astype(np.float32) / 255.0
    return arr
    